package com.example.stevendavis_option_3;

public class WeightEntry {

    // set up variables
    private String date;
    private String weight;


    // initialize variables
    public WeightEntry(String date, String weight) {
        this.date = date;
        this.weight = weight;
    }

    // getters for date and weight
    public String getDate() {
        return date;
    }

    public String getWeight() {
        return weight;
    }
}