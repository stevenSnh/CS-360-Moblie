package com.example.stevendavis_option_3;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataGridActivity extends AppCompatActivity {

    // set up variables UI components for input and display
    private WeightAdapter adapter;
    private EditText inputDate, inputWeight;
    private RecyclerView recyclerView;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        // link UI components from layout file
        inputDate = findViewById(R.id.inputDate);
        inputWeight = findViewById(R.id.inputWeight);
        addButton = findViewById(R.id.addDataButton);
        recyclerView = findViewById(R.id.recyclerViewGrid);
        Button backToMainButton = findViewById(R.id.buttonBackToMain);

        // set up back button to main screen
        backToMainButton.setOnClickListener(v -> finish());

        // initialize the adapter
        adapter = new WeightAdapter(WeightDataStore.getEntries(), this::removeEntry);


        // set up recyclerview with vertical scrolling list
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // handle button for adding new weight entry
        addButton.setOnClickListener(v -> {
            String date = inputDate.getText().toString().trim();
            String weight = inputWeight.getText().toString().trim();

            // validate input fields before adding
            if (TextUtils.isEmpty(date) || TextUtils.isEmpty(weight)) {
                Toast.makeText(this, "Enter both date and weight", Toast.LENGTH_SHORT).show();
            } else {
                WeightDataStore.addEntry(new WeightEntry(date, weight));
                adapter.notifyItemInserted(WeightDataStore.getEntries().size() - 1);
                inputDate.setText("");
                inputWeight.setText("");
            }
        });
    }

    // remove data and update recyclerview
    private void removeEntry(int position) {
        WeightDataStore.removeEntry(position);
        adapter.notifyItemRemoved(position);
    }
}
