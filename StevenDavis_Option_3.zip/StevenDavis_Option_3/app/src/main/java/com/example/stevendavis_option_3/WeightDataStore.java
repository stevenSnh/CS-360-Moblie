package com.example.stevendavis_option_3;

import java.util.ArrayList;
import java.util.List;

public class WeightDataStore {

    // create weight entry list
    private static final List<WeightEntry> weightEntries = new ArrayList<>();

    // method to add weight entries
    public static void addEntry(WeightEntry entry) {
        weightEntries.add(entry);
    }

    // method to return wight entries
    public static List<WeightEntry> getEntries() {
        return weightEntries;
    }


    // method to remove entries
    public static void removeEntry(int index) {
        if (index >= 0 && index < weightEntries.size()) {
            weightEntries.remove(index);
        }
    }

    public static void clear() {
        weightEntries.clear();
    }
}