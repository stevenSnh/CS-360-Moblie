package com.example.stevendavis_option_3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    // set up weight data list
    private List<WeightEntry> weightList;
    private final OnDeleteClickListener deleteClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    public WeightAdapter(List<WeightEntry> weightList, OnDeleteClickListener listener) {
        this.weightList = weightList;
        this.deleteClickListener = listener;
    }

    // set up view of data
    @NonNull
    @Override
    public WeightAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_data_row, parent, false);
        return new ViewHolder(view, deleteClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightAdapter.ViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);
        holder.dateText.setText(entry.getDate());
        holder.weightText.setText(entry.getWeight() + " lbs");
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }


    // set up class for view holder to extend recyclerview
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateText, weightText;
        Button deleteButton;

        // method for deletion
        ViewHolder(View itemView, OnDeleteClickListener listener) {
            super(itemView);
            dateText = itemView.findViewById(R.id.textDate);
            weightText = itemView.findViewById(R.id.textWeight);
            deleteButton = itemView.findViewById(R.id.buttonDelete);

            deleteButton.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onDeleteClick(position);
                    }
                }
            });
        }
    }
}
