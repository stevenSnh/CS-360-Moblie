package com.example.stevendavis_option_3;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "UserPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_LOGGED_IN = "logged_in";

    private ArrayList<WeightEntry> weightEntries;
    private WeightAdapter adapter;

    private static final int SMS_PERMISSION_CODE = 123;
    private LinearLayout rootLayout;

    private boolean isLoggedIn = false;

    private void saveUserCredentials(String username, String password) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putString(KEY_USERNAME, username)
                .putString(KEY_PASSWORD, password)
                .apply();
    }
    private boolean validateUserCredentials(String username, String password) {
        String savedUsername = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_USERNAME, null);
        String savedPassword = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_PASSWORD, null);

        return username.equals(savedUsername) && password.equals(savedPassword);
    }

    private void setLoggedIn(boolean loggedIn) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_LOGGED_IN, loggedIn)
                .apply();
    }

    private boolean getLoggedIn() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_LOGGED_IN, false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        setContentView(rootLayout);

        isLoggedIn = getLoggedIn();

        if (!isLoggedIn) {
            showLoginScreen();
        } else {
            showWeightTrackerScreen();
        }
    }

    // show login screen the first screen method
    private void showLoginScreen() {
        rootLayout.removeAllViews();
        View loginView = getLayoutInflater().inflate(R.layout.activity_login, rootLayout, false);
        rootLayout.addView(loginView);

        // Get reference for username and password
        EditText usernameInput = loginView.findViewById(R.id.usernameInput);
        EditText passwordInput = loginView.findViewById(R.id.passwordInput);
        Button loginButton = loginView.findViewById(R.id.loginButton);
        Button createAccountButton = loginView.findViewById(R.id.createAccountButton);

        // handles button input
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString();

            // validate all inputs
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            } else if (validateUserCredentials(username, password)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                isLoggedIn = true;
                setLoggedIn(true);  // persist login state
                showWeightTrackerScreen();
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // create account for users
        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString();

            // if user name doesn't exist create account and save credentials
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            } else {
                // Save credentials if they don't exist yet
                String savedUsername = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_USERNAME, null);
                if (savedUsername != null && savedUsername.equals(username)) {
                    Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
                } else {
                    saveUserCredentials(username, password);
                    Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // show weight tracker the main screen method

    private void showWeightTrackerScreen() {

        // remove views and create weight tracker view
        rootLayout.removeAllViews();
        View weightView = getLayoutInflater().inflate(R.layout.activity_weight_tracker, rootLayout, false);
        rootLayout.addView(weightView);

        // set up buttons
        RecyclerView recyclerView = weightView.findViewById(R.id.recyclerViewGrid);
        EditText goalInput = weightView.findViewById(R.id.inputGoalWeight);
        Button setGoalButton = weightView.findViewById(R.id.setGoalWeightButton);
        Button smsPermissionButton = weightView.findViewById(R.id.buttonSmsPermission);
        Button viewHistoryButton = weightView.findViewById(R.id.buttonViewHistory);


        // initialize adapter to populate data from the weight data list
        adapter = new WeightAdapter(WeightDataStore.getEntries(), position -> {

            // allow the deletion of data
            WeightDataStore.removeEntry(position);
            adapter.notifyItemRemoved(position);
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);


        // set goal weight button
        setGoalButton.setOnClickListener(v -> {
            String goal = goalInput.getText().toString().trim();
            if (!goal.isEmpty()) {
                Toast.makeText(this, "Goal set to " + goal + " lbs", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Enter goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        smsPermissionButton.setOnClickListener(v -> showSmsPermissionScreen());

        // view weight history button and go to weight input screen
        viewHistoryButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, DataGridActivity.class);
            startActivity(intent);
        });

        // handle users logout
        Button logoutButton = weightView.findViewById(R.id.buttonLogout);
        logoutButton.setOnClickListener(v -> {
            isLoggedIn = false;
            showLoginScreen();
        });


    }
    // Show sms permission screen method
    private void showSmsPermissionScreen() {

        // inflate the sms permission layout screen
        rootLayout.removeAllViews();
        View smsView = getLayoutInflater().inflate(R.layout.activity_sms_permission, rootLayout, false);
        rootLayout.addView(smsView);


        // set permission button and status text view
        Button requestButton = smsView.findViewById(R.id.requestPermissionButton);
        TextView permissionStatus = smsView.findViewById(R.id.permissionStatus);
        Button backButton = smsView.findViewById(R.id.buttonBackToWeightTracker);  // find the back button

        // Check and display current permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            permissionStatus.setText("Permission Status: Granted");
        } else {
            permissionStatus.setText("Permission Status: Denied");
        }

        // button for sms permission request when clicked
        requestButton.setOnClickListener(v -> {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        });

        // button to return to main screen
        backButton.setOnClickListener(v -> showWeightTrackerScreen());  // go back to weight tracker screen
    }

    // to ensure correct data is displayed
    @Override
    protected void onResume() {
        super.onResume();

        if (isLoggedIn) {
            showWeightTrackerScreen();
        } else {
            showLoginScreen();
        }
    }

    // request permission method
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
            showSmsPermissionScreen();
        }
    }

}